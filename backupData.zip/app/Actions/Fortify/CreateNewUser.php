<?php

namespace App\Actions\Fortify;

use App\Models\Question;
use App\Models\TestAttempt;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array<string, string>  $input
     */
    // public function create(array $input): User
    // {
    //     Validator::make($input, [
    //         'name' => ['required', 'string', 'max:255'],
    //         'email' => [
    //             'required',
    //             'string',
    //             'email',
    //             'max:255',
    //             Rule::unique(User::class),
    //         ],
    //         'password' => $this->passwordRules(),
    //         'role' => ['required', 'string', 'in:student,counsellor,professional,institute'],
    //     ])->validate();

    //     $user = User::create([
    //         'name' => $input['name'],
    //         'email' => $input['email'],
    //         'password' => $input['password'],
    //     ]);

    //     // Assign the selected role
    //     $user->assignRole($input['role']);

    //     return $user;
    // }

    public function create(array $input): User
    {
        Validator::make($input, [
            'name' => ['required', 'string', 'max:255'],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique(User::class),
            ],
            'password' => $this->passwordRules(),
            'role' => ['required', 'string', 'in:student,counsellor,professional,institute'],
        ])->validate();

        // ✅ STEP 1: Create User
        $user = User::create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => $input['password'],
        ]);

        // ✅ STEP 2: Assign Role
        $user->assignRole($input['role']);

        // 🔥🔥🔥 YAHI SE TERA MAIN LOGIC START HOGA 🔥🔥🔥

        // ✅ Check if free test session exists
        if (session()->has('free_test_answers')) {

            $answers = session()->get('free_test_answers');
            $testId = session()->get('free_test_id');

            // ✅ Step 1: Create Test Attempt
            $attempt = TestAttempt::create([
                'user_id' => $user->id,
                'test_id' => $testId,
                'status' => 'in_progress',
                'start_time' => now(),
            ]);

            // ✅ Step 2: Save answers
            foreach ($answers as $ans) {
                $attempt->answers()->create([
                    'question_id' => $ans['question_id'],
                    'option_id' => $ans['option_id'],
                    'status' => $ans['status'],
                ]);
            }

            // ✅ Step 3: Fill unanswered questions
            $answeredIds = collect($answers)->pluck('question_id')->toArray();

            $allQuestionIds = Question::whereHas('part.section', function ($q) use ($testId) {
                $q->where('test_id', $testId);
            })->pluck('id')->toArray();

            $unanswered = array_diff($allQuestionIds, $answeredIds);

            foreach ($unanswered as $qid) {
                $attempt->answers()->create([
                    'question_id' => $qid,
                    'status' => 'skipped',
                ]);
            }

            // ✅ Step 4: Calculate score
            $totalScore = 0;

            foreach ($attempt->answers()->with('option', 'question')->get() as $answer) {
                if ($answer->option && $answer->option->is_correct) {
                    $totalScore += $answer->question->marks;
                }
            }

            // ✅ Step 5: Update attempt
            $attempt->update([
                'status' => 'completed',
                'score' => $totalScore,
                'end_time' => now(),
            ]);

            // ✅ Step 6: Clear session
            session()->forget('free_test_answers');
            session()->forget('free_test_id');
        }

        // 🔥🔥🔥 END LOGIC 🔥🔥🔥

        return $user;
    }
}
