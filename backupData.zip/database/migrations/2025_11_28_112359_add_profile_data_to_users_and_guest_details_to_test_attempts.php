<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->json('profile_data')->nullable()->after('remember_token');
        });

        Schema::table('test_attempts', function (Blueprint $table) {
            $table->json('guest_details')->nullable()->after('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('profile_data');
        });

        Schema::table('test_attempts', function (Blueprint $table) {
            $table->dropColumn('guest_details');
        });
    }
};
