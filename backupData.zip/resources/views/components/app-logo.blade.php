<img src="{{ asset('logo.png') }}" alt="{{ config('app.name') }}" class="h-10" />
