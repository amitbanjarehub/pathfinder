<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="dark">

<head>
    @include('partials.head')
</head>

<body class="min-h-screen bg-white antialiased dark:bg-linear-to-b dark:from-neutral-950 dark:to-neutral-900">
    <div
        class="relative grid h-dvh flex-col items-center justify-center px-8 sm:px-0 lg:max-w-none lg:grid-cols-2 lg:px-0">
        <div
            class="bg-muted relative hidden h-full flex-col p-10 text-white lg:flex dark:border-e dark:border-neutral-800">
            @php
                $authBgImage = App\Models\SiteSetting::get('auth_background_image');
                $bgUrl = $authBgImage ? Storage::url($authBgImage) : asset('auth-bg.webp');
            @endphp
            <div class="absolute inset-0 bg-cover bg-center" style="background-image: url('{{ $bgUrl }}');">
            </div>
            <div class="absolute inset-0 bg-black/50"></div>
            <a href="{{ route('home') }}"
                class="relative z-20 flex items-center gap-3 text-xl font-bold font-sans text-white" wire:navigate>
                <x-app-logo-icon class="h-10" />
                {{ config('app.name', 'Laravel') }}
            </a>

            @php
                [$message, $author] = str(Illuminate\Foundation\Inspiring::quotes()->random())->explode('-');
            @endphp

            <div class="relative z-20 mt-auto">
                <blockquote class="space-y-2 text-white">
                    <p class="text-lg text-white font-medium">&ldquo;{{ trim($message) }}&rdquo;</p>
                    <footer>
                        <p class="text-white/80">{{ trim($author) }}</p>
                    </footer>
                </blockquote>
            </div>
        </div>
        <div class="w-full lg:p-8">
            <div class="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[350px]">
                <a href="{{ route('home') }}" class="z-20 flex flex-col items-center gap-2 font-medium lg:hidden"
                    wire:navigate>
                    <span class="flex h-9 w-9 items-center justify-center rounded-md">
                        <x-app-logo-icon class="size-9 fill-current text-black dark:text-white" />
                    </span>

                    <span class="sr-only">{{ config('app.name', 'Laravel') }}</span>
                </a>
                {{ $slot }}
            </div>
        </div>
    </div>
    @fluxScripts
</body>

</html>
