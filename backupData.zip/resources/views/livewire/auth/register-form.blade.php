<div class="flex flex-col gap-6">
    <h2 class="text-xl font-bold text-center">Create Account</h2>

    <form method="POST" action="{{ route('register.store') }}" class="flex flex-col gap-4">
        @csrf

        <input name="name" type="text" placeholder="Full name" class="border p-2 rounded" required>

        <input name="email" type="email" placeholder="Email" class="border p-2 rounded" required>

        <input name="password" type="password" placeholder="Password" class="border p-2 rounded" required>

        <input name="password_confirmation" type="password" placeholder="Confirm Password" class="border p-2 rounded" required>

        <select name="role" class="border p-2 rounded">
            <option value="student">Student</option>
            <option value="counsellor">Counsellor</option>
            <option value="professional">Professional</option>
            <option value="institute">Institute</option>
        </select>

        <button type="submit" class="bg-indigo-600 text-white py-2 rounded">
            Create Account
        </button>
    </form>
</div>