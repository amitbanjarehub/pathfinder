<x-layouts.public title="About Us - Miracles">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

        {{-- <div class="flex flex-wrap sm:flex-nowrap justify-center items-center py-6">
            <div class="flex flex-col">
                <h1 class="text-3xl font-bold mb-4 text-accent">PROCESS (HOW IT WORKS)</h1>
                <p class="text-lg italic text-gray-700 mb-4">
                  “From Discovery to Direction to Destination.”
                </p>
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">At PATH finder, we offer three types of career counselling support — the Discovery Module, the Direction Module, and the Destination Module - allowing individuals to choose what best fits their current needs.</p>
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">🔍Discovery ModuleProcess (Career Counselling)</p>

                 <p class="text-xl max-w-2xl text-gray-700 mb-8">
                  “Understand Yourself Before You Decide”<br>
                  The Discovery Module is the foundation of the entire PATH Finder journey.
                 </p>
                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">It is designed to help students and parents gain deep clarity about the student’s natural strengths, interests, personality traits, and thinking patterns—before any major academic or career decision is made.</p>
                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">In this module, the student undertakes scientifically designed psychometric tests (assessments), chosen based on age and career stage. The outcome is a comprehensive, easy-to-understand report presented in both narrative and graphical formats.</p>
                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">The PDF report is:<br>
                 <ul class="list-disc pl-6 text-gray-700 space-y-1 max-w-2xl mb-8">
                 <li>Clear and Self-explanatory</li>
                 <li>Visually appealing and clutter-free presentation</li>
                 <li>Free from complex jargon</li>
                 <li>Easily understandable by students and parents alike without Counsellor’s help</li>
                 <li>It helps answer critical questions such as:
                 <ul class="list-circle pl-0 mt-1">
                    <li>- What am I naturally good at?</li>
                    <li>- Where do my interests and aptitude genuinely intersect?</li>
                    <li>- Which fields align with my abilities and temperament?</li>
                 </ul>
                 
                 </ul>
                 </p>

                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">The Discovery Module does not give advice—it gives clarity.<br>It ensures that future decisions are based on self-awareness, not assumptions or social pressure.</p>
                  <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">It follows a simple, structured, and transparent process designed for students and parents alike.</p>

                
            </div>
           

                <img src="{{ asset('/assets/images/discover.jpeg') }}" alt="Discover"
                class="rounded-xl shadow-lg w-full max-w-xl lg:max-w-md xl:max-w-xl mx-auto">
        </div> --}}

        <div class="flex flex-col lg:flex-row gap-8 lg:gap-12 items-start">
                <div class="flex flex-col">
                <h1 class="text-3xl font-bold mb-4 text-accent">PROCESS (HOW IT WORKS)</h1>
                <p class="text-lg italic text-gray-700 mb-4">
                  “From Discovery to Direction to Destination.”
                </p>
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">At PATH finder, we offer three types of career counselling support — the Discovery Module, the Direction Module, and the Destination Module - allowing individuals to choose what best fits their current needs.</p>
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">🔍Discovery ModuleProcess (Career Counselling)</p>

                 <p class="text-xl max-w-2xl text-gray-700 mb-8">
                  “Understand Yourself Before You Decide”<br>
                  The Discovery Module is the foundation of the entire PATH Finder journey.
                 </p>
                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">It is designed to help students and parents gain deep clarity about the student’s natural strengths, interests, personality traits, and thinking patterns—before any major academic or career decision is made.</p>
                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">In this module, the student undertakes scientifically designed psychometric tests (assessments), chosen based on age and career stage. The outcome is a comprehensive, easy-to-understand report presented in both narrative and graphical formats.</p>
                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">The PDF report is:<br>
                 <ul class="list-disc pl-6 text-gray-700 space-y-1 max-w-2xl mb-8">
                 <li>Clear and Self-explanatory</li>
                 <li>Visually appealing and clutter-free presentation</li>
                 <li>Free from complex jargon</li>
                 <li>Easily understandable by students and parents alike without Counsellor’s help</li>
                 <li>It helps answer critical questions such as:
                 <ul class="list-circle pl-0 mt-1">
                    <li>- What am I naturally good at?</li>
                    <li>- Where do my interests and aptitude genuinely intersect?</li>
                    <li>- Which fields align with my abilities and temperament?</li>
                 </ul>
                 
                 </ul>
                 </p>

                 <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">The Discovery Module does not give advice—it gives clarity.<br>It ensures that future decisions are based on self-awareness, not assumptions or social pressure.</p>
                  <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">It follows a simple, structured, and transparent process designed for students and parents alike.</p>

                
            </div>

                <div class="w-full lg:w-5/12 xl:w-1/3 shrink-0 flex justify-center sticky top-8">
                    <img src="{{ asset('/assets/images/discover.jpeg') }}" alt="Founder's Note"
                        class="rounded-xl shadow-lg w-full max-w-md lg:max-w-full">
                </div>
</div>
       
</x-layouts.public>