<x-layouts.public title="About Us - Miracles">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

        <div class="flex flex-wrap sm:flex-nowrap justify-center items-center py-6">
            <div class="flex flex-col">
                <h1 class="text-3xl font-bold mb-4 text-accent">Stories (Who We Are)</h1>
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">PATH finder is India’s one of the oldest career
                    counselling and mentoring platforms founded by Shyam Verma, with 20+ years of experience guiding
                    20,000+ students towards clarity, confidence, and meaningful careers.</p>
            </div>
            <img src="{{ asset('/assets/images/about.png') }}" alt="About Us"
                class="rounded-xl shadow-lg w-full max-w-xl mx-auto">
        </div>



        <div class="py-8">
            <h1 class="text-3xl font-bold mb-4 text-accent">Know Our Philosophy</h1>
            <p class=" text-xl  text-gray-700 mb-8 ">At PATH finder, we believe <strong class>
                    CAREER DECISIONS SHOULD BE
                    GUIDED BY DEEP SELF-AWARENESS, NOT SOCIAL PRESSURE OR SHORT-TERM TRENDS.
                </strong>
            </p>
        </div>

        <div class="flex  flex-wrap sm:flex-nowrap gap-8 py-8 justify-end items-end">
            <div class="flex flex-col">
                <h1 class="text-3xl font-bold mb-4 text-accent">More about Us</h1>
                <img src="{{ asset('/assets/images/more-about-us.jpeg') }}" alt="About Us"
                    class="rounded-xl shadow-lg w-full max-w-xl mx-auto">
            </div>

            <div class="flex flex-col">
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">We help students understand their aptitudes,
                    personality traits, interests, and cognitive strengths before choosing a direction - so decisions
                    are rooted in clarity, not confusion.</p>
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">Our counselling approach blends scientifically
                    designed psychometric assessments with two decades of real-world mentoring experience.</p>
                <p class=" text-xl max-w-2xl text-gray-700 mb-8 ">Backed by over 20 years of counselling and mentoring
                    experience, PATH finder has helped thousands of students in India and abroad make confident,
                    well-informed, and future-ready career choices.</p>
            </div>
        </div>
        <a class='text-accent font-bold underline decoration-dotted' href="#"> Meet the Mentor Behind PATH finder
            ->
        </a>

        <div class="pt-12">
            <h1 class="text-3xl font-bold mb-8 text-accent">Founder’s Note</h1>

            <div class="flex flex-col lg:flex-row gap-8 lg:gap-12 items-start">
                <div class="flex-1">
                    <p class="text-xl text-gray-700 mb-4">Hello Friends,</p>
                    <p class="text-xl text-gray-700 mb-4">Namaste.</p>
                    <p class="text-xl text-gray-700 mb-4">I am extremely Happy to see you here</p>
                    <p class="text-xl text-gray-700 mb-4">Welcome to the World of Awareness!</p>
                    <p class="text-xl text-gray-700 mb-8">Welcome to the World of Opportunities!</p>

                    <p class="text-xl text-gray-700 mb-4">Welcome to PATH finder!</p>
                    <p class="text-xl text-gray-700 mb-4">I am Shyam Verma, I was raised in a humble family of
                        BHEL, Bhopal with limited resources but strong values. What shaped my life was not privilege,
                        but
                        the habit of questioning my own decisions, understanding myself deeply, and choosing paths
                        logically
                        at every stage.</p>
                    <p class="text-xl text-gray-700 mb-4">Before turning 30, I achieved milestones, many only
                        dream of, simply because I understood myself well & took well informed decisions at crucial
                        junctures.</p>
                    <p class="text-xl text-gray-700 mb-4">I chose career counselling & training students as my
                        profession over a conventional corporate career because I believed that if self-awareness &
                        self-belief could transform the life of an ordinary person like me then they (/it) could surely
                        do
                        the same for millions of such students who lack proper career guidance and need a few words of
                        encouragement (at a right time/ at a time when the whole world either criticizes them or
                        misunderstands them.</p>
                    <p class="text-xl text-gray-700 mb-4">For over 20 years, I have listened to students,
                        understood their uniqueness, and helped them believe bigger than their circumstances. PATH
                        finder is
                        an extension of that belief. So, once again I warmly welcome you to an awe-inspiring wonderland
                        called - PATH finder and eagerly waiting to meet you at one of counselling sessions.</p>
                    <p class="text-xl text-gray-700 font-bold mt-8">— Shyam Verma</p>
                </div>

                <div class="w-full lg:w-5/12 xl:w-1/3 shrink-0 flex justify-center sticky top-8">
                    <img src="{{ asset('/assets/images/founders-note.jpeg') }}" alt="Founder's Note"
                        class="rounded-xl shadow-lg w-full max-w-md lg:max-w-full">
                </div>
            </div>
        </div>

        <div class="py-16">
            <div class="text-center mb-10">
                <h2 class="text-3xl font-bold text-accent">Success Stories</h2>
                <p class="text-gray-600 mt-2">
                    Real experiences shared by students and parents
                </p>
            </div>

            @php
                $stories = [
                    [
                        'type' => 'video',
                        'title' => 'PATH finder changed my career direction completely.',
                        'author' => 'Shubham',
                        'role' => 'B.Tech Student',
                        'thumbnail' => 'https://img.youtube.com/vi/jNQXAC9IVRw/maxresdefault.jpg',
                        'video' => 'https://www.youtube.com/embed/jNQXAC9IVRw',
                    ],
                    [
                        'type' => 'blog',
                        'title' => 'At the age the assessment test and about myself really helped me.',
                        'author' => 'Shikha',
                        'role' => 'Student',
                        'image' => 'https://randomuser.me/api/portraits/women/44.jpg',
                    ],
                    [
                        'type' => 'blog',
                        'title' => 'My elder provided a renewed framework for my possibilities.',
                        'author' => 'Kanha',
                        'role' => 'Parent',
                        'image' => 'https://randomuser.me/api/portraits/men/32.jpg',
                    ],
                    [
                        'type' => 'blog',
                        'title' =>
                            'Speaking to Mr. Verma and meeting and interacting with other experienced team was inspiring.',
                        'author' => 'Shreya',
                        'role' => 'High School Student',
                        'image' => 'https://randomuser.me/api/portraits/women/65.jpg',
                    ],
                    [
                        'type' => 'blog',
                        'title' => 'Now I truly consider his influence and advice to choose the smartest path ahead.',
                        'author' => 'Ritesh',
                        'role' => 'Engineering Student',
                        'image' => 'https://randomuser.me/api/portraits/men/51.jpg',
                    ],
                    [
                        'type' => 'video',
                        'title' => 'Before & After counselling experience.',
                        'author' => 'Aman',
                        'role' => 'Student',
                        'thumbnail' => 'https://img.youtube.com/vi/jNQXAC9IVRw/maxresdefault.jpg',
                        'video' => 'https://youtu.be/OMBo1He1myg?si=j8PkN5ARaFMIrq3s',
                    ],
                ];
            @endphp

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">

                @foreach ($stories as $story)
                    <div
                        class="bg-white rounded-2xl shadow-md hover:shadow-xl transition duration-300 overflow-hidden border border-gray-100">

                        {{-- VIDEO CARD --}}
                        @if ($story['type'] === 'video')
                            <div class="relative aspect-video">
                                <iframe class="w-full h-full" src="{{ $story['video'] }}" title="Video Story"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen>
                                </iframe>
                            </div>

                            <div class="p-5">
                                <p class="text-gray-700 text-sm leading-relaxed mb-4">
                                    {{ $story['title'] }}
                                </p>

                                <div class="flex items-center gap-3">
                                    <img src="https://ui-avatars.com/api/?name={{ urlencode($story['author']) }}"
                                        class="w-10 h-10 rounded-full object-cover">

                                    <div>
                                        <h4 class="font-semibold text-gray-800">
                                            {{ $story['author'] }}
                                        </h4>
                                        <p class="text-sm text-gray-500">
                                            {{ $story['role'] }}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {{-- BLOG CARD --}}
                        @else
                            <div class="p-5 h-full flex flex-col justify-between">

                                <div>
                                    <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-accent mb-3 opacity-70"
                                        fill="currentColor" viewBox="0 0 24 24">
                                        <path
                                            d="M7.17 6A5.001 5.001 0 0 0 2 11v7h7v-7H5.08A3.001 3.001 0 0 1 8 8.08V6H7.17zm9 0A5.001 5.001 0 0 0 11 11v7h7v-7h-3.92A3.001 3.001 0 0 1 17 8.08V6h-.83z" />
                                    </svg>

                                    <p class="text-gray-700 text-sm leading-relaxed mb-6">
                                        {{ $story['title'] }}
                                    </p>
                                </div>

                                <div class="flex items-center gap-3 mt-auto">
                                    <img src="{{ $story['image'] }}" class="w-10 h-10 rounded-full object-cover">

                                    <div>
                                        <h4 class="font-semibold text-gray-800">
                                            {{ $story['author'] }}
                                        </h4>
                                        <p class="text-sm text-gray-500">
                                            {{ $story['role'] }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                @endforeach

            </div>
        </div>

    </div>
</x-layouts.public>
