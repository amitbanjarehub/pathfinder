<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
        <div class="mb-6 bg-red-500/20 border border-red-500/50 text-red-100 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$test): ?>
        <div class="text-center">
            <h2 class="text-2xl font-bold text-white mb-6"><?php echo e(__('Enter Test Code')); ?></h2>
            <p class="text-white/80 mb-6"><?php echo e(__('Enter your unique test code to begin the assessment')); ?></p>

            <form wire:submit="findTestByCode" class="max-w-md mx-auto">
                <div class="mb-6">
                    <input type="text" wire:model="testCode" placeholder="<?php echo e(__('Enter Test Code')); ?>"
                        class="block w-full text-center text-3xl font-mono tracking-wider px-4 py-4 rounded-lg bg-white/20 backdrop-blur-sm border-2 border-white/30 text-white placeholder-white/50 focus:border-white focus:ring-2 focus:ring-white/50 uppercase">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['testCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-300 text-sm block mt-2"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <button type="submit"
                    class="w-full px-6 py-4 bg-white text-indigo-900 rounded-lg hover:bg-white/90 transition-all font-semibold text-lg shadow-xl">
                    <?php echo e(__('Find Test')); ?>

                </button>
            </form>
        </div>
    <?php else: ?>
        <div class="text-center">
            <div class="mb-8">
                <h3 class="text-3xl font-bold text-white mb-3"><?php echo e($test->title); ?></h3>
                <p class="text-white/80 text-lg"><?php echo e($test->description); ?></p>
            </div>

            <div class="bg-white/10 rounded-xl p-6 mb-8 max-w-md mx-auto">
                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <p class="text-sm text-white/60 mb-1"><?php echo e(__('Type')); ?></p>
                        <p class="text-2xl font-bold text-white"><?php echo e(ucfirst($test->type)); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-white/60 mb-1"><?php echo e(__('Sections')); ?></p>
                        <p class="text-2xl font-bold text-white"><?php echo e($test->sections->count()); ?></p>
                    </div>
                </div>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                <div class="max-w-xl mx-auto mb-8 bg-white/10 rounded-xl p-6 backdrop-blur-sm border border-white/20">
                    <h4 class="text-xl font-semibold text-white mb-4 text-left"><?php echo e(__('Guest Details')); ?></h4>
                    <p class="text-white/70 text-sm mb-6 text-left"><?php echo e(__('Please provide your details to continue.')); ?>

                    </p>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                        <div>
                            <label class="block text-white/80 text-sm font-medium mb-1"><?php echo e(__('Full Name')); ?></label>
                            <input type="text" wire:model="guest_details.name"
                                class="w-full px-4 py-2 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/50 focus:ring-2 focus:ring-white/50 focus:border-white/50">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['guest_details.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-300 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div>
                            <label class="block text-white/80 text-sm font-medium mb-1"><?php echo e(__('Email')); ?></label>
                            <input type="email" wire:model="guest_details.email"
                                class="w-full px-4 py-2 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/50 focus:ring-2 focus:ring-white/50 focus:border-white/50">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['guest_details.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-300 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div>
                            <label class="block text-white/80 text-sm font-medium mb-1"><?php echo e(__('Mobile Number')); ?></label>
                            <input type="tel" wire:model="guest_details.mobile"
                                class="w-full px-4 py-2 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/50 focus:ring-2 focus:ring-white/50 focus:border-white/50">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['guest_details.mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-300 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div>
                            <label class="block text-white/80 text-sm font-medium mb-1"><?php echo e(__('City')); ?></label>
                            <input type="text" wire:model="guest_details.city"
                                class="w-full px-4 py-2 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/50 focus:ring-2 focus:ring-white/50 focus:border-white/50">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['guest_details.city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-300 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="md:col-span-2">
                            <label
                                class="block text-white/80 text-sm font-medium mb-1"><?php echo e(__('School / Institute (Optional)')); ?></label>
                            <input type="text" wire:model="guest_details.school"
                                class="w-full px-4 py-2 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/50 focus:ring-2 focus:ring-white/50 focus:border-white/50">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['guest_details.school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-300 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <button wire:click="$set('test', null)"
                    class="px-8 py-4 bg-white/20 backdrop-blur-sm text-white rounded-lg hover:bg-white/30 transition-all font-semibold border-2 border-white/30">
                    <?php echo e(__('Change Code')); ?>

                </button>
                <button wire:click="startTest"
                    class="px-8 py-4 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-all font-semibold shadow-xl text-lg">
                    <?php echo e(__('Start Test Now')); ?> →
                </button>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->guest()): ?>
                <p class="text-white/60 text-sm mt-6">
                    <?php echo e(__('Have an account?')); ?>

                    <a href="<?php echo e(route('login')); ?>"
                        class="text-white underline hover:text-white/80"><?php echo e(__('Login here')); ?></a>
                </p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH K:\websites\pathfinder\resources\views/livewire/start-test-public.blade.php ENDPATH**/ ?>